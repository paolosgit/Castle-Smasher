//
// Created by Paolo Octoman on 1/16/23.
//

#ifndef WHATEVER_NODE_H
#define WHATEVER_NODE_H
template <typename T>
struct Node{
    T data;
    Node* next;
};
#endif //WHATEVER_NODE_H
